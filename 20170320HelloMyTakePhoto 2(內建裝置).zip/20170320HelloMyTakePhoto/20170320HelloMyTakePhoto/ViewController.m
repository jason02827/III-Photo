//
//  ViewController.m
//  20170320HelloMyTakePhoto
//
//  Created by user35 on 2017/3/20.
//  Copyright © 2017年 user35. All rights reserved.
//

#import "ViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <Photos/Photos.h>
@interface ViewController ()  <UINavigationControllerDelegate,UIImagePickerControllerDelegate>
@property (weak, nonatomic) IBOutlet UISegmentedControl *sourceTypeSegment;
@property (weak, nonatomic) IBOutlet UIImageView *resultImageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)goBtnPressed:(id)sender {
    
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypePhotoLibrary; //來源為何
    
    if (_sourceTypeSegment.selectedSegmentIndex == 0) {
        sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    }else if (_sourceTypeSegment.selectedSegmentIndex == 1){
        sourceType = UIImagePickerControllerSourceTypeCamera;
    }
    //Check if this source type is supported
    if ([UIImagePickerController isSourceTypeAvailable:sourceType == false]) {
        NSLog(@"source type is not supportes");
        return;
    }
    
    
    UIImagePickerController *picker = [UIImagePickerController new];
    picker.sourceType = sourceType;
//    picker.mediaTypes = @[@"public.image",@"public.movie"];  //照片跟影片
    picker.mediaTypes = @[(NSString*)kUTTypeImage,(NSString*)kUTTypeMovie];  //搭配#import <MobileCoreServices/MobileCoreServices.h>
    //加入裁切
//    picker.allowsEditing = true;
    
    picker.delegate = self;
    
    
    if (sourceType == UIImagePickerControllerSourceTypeCamera) {
        picker.allowsEditing = false;
        picker.showsCameraControls = false;
        
        //Add a button
        UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        button.frame = CGRectMake(20, 20, 80, 30);
        [button setTitle:@"Take" forState:UIControlStateNormal];
        [button addTarget:picker action:@selector(takePicture) forControlEvents:UIControlEventTouchUpInside];
        [picker.cameraOverlayView addSubview:button];
        
    }else{
        picker.allowsEditing = true;
    }
    
    
    [self presentViewController:picker animated:YES completion:nil];

}

#pragma mark - UIImagePickerControllerDelegate Methods

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    
    NSLog(@"Info: %@",info.description);
    NSString *type = info[UIImagePickerControllerMediaType];
    
    if ([type isEqualToString:(NSString *)kUTTypeImage]) {
        //For Image
        UIImage *originalImage = info[UIImagePickerControllerOriginalImage];
        UIImage *editedImage = info[UIImagePickerControllerEditedImage];
        
        UIImage *finalImage = editedImage;
        if (finalImage == nil) {
            finalImage = originalImage;
        }
        
        UIImage *modifiedImage = [self modifyImage:finalImage];
        _resultImageView.image =modifiedImage;
        
//        _resultImageView.image = finalImage;
//        _resultImageView.image = originalImage;
        
        //Save modifiedImage with Photos Framework
        PHPhotoLibrary *library = [PHPhotoLibrary sharedPhotoLibrary];
        [library performChanges:^{
            [PHAssetChangeRequest creationRequestForAssetFromImage:modifiedImage];
        } completionHandler:^(BOOL success, NSError * _Nullable error) {
            if (success) {
                NSLog(@"Save Image OK.");
            }else{
                NSLog(@"Save Image Fail: %@",error);
            }
            
        }];
        
        
        
    }else if ([type isEqualToString:(NSString *)kUTTypeMovie]){
        //For Movie
        NSURL *movieFileURL = info[UIImagePickerControllerMediaURL];
        //Use movieFileURL
        
        //Remove file if it is no longer used
        [[NSFileManager defaultManager]removeItemAtURL:movieFileURL error:nil];
    }
    //Important
    [picker dismissViewControllerAnimated:true completion:nil];
}

-(UIImage *) modifyImage:(UIImage *)inputImage{
    
    CGSize finalSize = CGSizeMake(500, 500);
    
    UIGraphicsBeginImageContext(finalSize);   //C的方式,用C的方式不支援MRC，必須手動釋放記憶體
    
    CGRect drawRect = CGRectMake(0, 0, finalSize.width, finalSize.height);
    
    //Draw background
    [inputImage drawInRect:drawRect];
    //Draw frame 畫上邊框
    UIImage *frameImage = [UIImage imageNamed:@"frame_01.png"];
    [frameImage drawInRect:drawRect];
    
    //Draw Text
    NSString *text = @"早安!🐌☛";
    UIColor *color = [UIColor redColor];
    UIFont *font = [UIFont systemFontOfSize:80];
    
    NSDictionary *attributes = @{NSFontAttributeName:font, NSForegroundColorAttributeName:color};
    
    CGSize textSize = [text sizeWithAttributes:attributes];
    CGFloat xDelete = (finalSize.width - textSize.width)/2;
    CGPoint drawPoint = CGPointMake(xDelete, 0);
    
    [text drawAtPoint:drawPoint withAttributes:attributes];    //置中
//    [text drawAtPoint:CGPointZero withAttributes:attributes];  //置左
    
    UIImage *result = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();  //Important  在這裡釋放
    
    return result;
}

@end











